import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './components/auth/PrivateRoute';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import PatientsPage from './pages/PatientsPage';
import RecordsPage from './pages/RecordsPage';
import UsersPage from './pages/UsersPage';
import HospitalsPage from './pages/HospitalsPage';
import SecurityAlertsPage from './pages/SecurityAlertsPage';
import AIAnalysisPage from './pages/AIAnalysisPage';
import AuditLogsPage from './pages/AuditLogsPage';
import AccessRequestsPage from './pages/AccessRequestsPage';
import VitalsPage from './pages/VitalsPage';
import MyAccessPage from './pages/MyAccessPage';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route element={<PrivateRoute />}>
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/patients" element={<PatientsPage />} />
            <Route path="/records" element={<RecordsPage />} />
            <Route path="/vitals" element={<VitalsPage />} />
            <Route path="/access-requests" element={<AccessRequestsPage />} />
            <Route path="/my-access" element={<MyAccessPage />} />
          </Route>
          <Route element={<PrivateRoute allowedRoles={['admin']} />}>
            <Route path="/users" element={<UsersPage />} />
            <Route path="/hospitals" element={<HospitalsPage />} />
            <Route path="/audit-logs" element={<AuditLogsPage />} />
            <Route path="/security-alerts" element={<SecurityAlertsPage />} />
            <Route path="/ai-analysis" element={<AIAnalysisPage />} />
          </Route>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
