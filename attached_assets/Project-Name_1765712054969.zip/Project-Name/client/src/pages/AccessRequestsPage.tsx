import { useEffect, useState } from 'react';
import { accessRequestService } from '../services/api';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { ClipboardList, Check, X, Clock } from 'lucide-react';

interface AccessRequest {
  id: number;
  requester_id: number;
  patient_id: number;
  reason: string;
  status: string;
  requested_at: string;
  reviewed_at?: string;
  requester?: {
    full_name: string;
    role: string;
  };
  patient?: {
    user?: {
      full_name: string;
    };
  };
}

export default function AccessRequestsPage() {
  const { user } = useAuth();
  const [requests, setRequests] = useState<AccessRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');

  useEffect(() => {
    loadRequests();
  }, [filter]);

  const loadRequests = async () => {
    try {
      const response = await accessRequestService.getAll({
        status: filter === 'all' ? undefined : filter,
      });
      setRequests(response.data.requests);
    } catch (error) {
      console.error('Failed to load requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: number) => {
    try {
      await accessRequestService.approve(id);
      loadRequests();
    } catch (error: any) {
      alert(error.response?.data?.error || 'Failed to approve request');
    }
  };

  const handleDeny = async (id: number) => {
    try {
      await accessRequestService.deny(id);
      loadRequests();
    } catch (error: any) {
      alert(error.response?.data?.error || 'Failed to deny request');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <span className="flex items-center text-yellow-600"><Clock size={16} className="mr-1" /> Pending</span>;
      case 'approved':
        return <span className="flex items-center text-green-600"><Check size={16} className="mr-1" /> Approved</span>;
      case 'denied':
        return <span className="flex items-center text-red-600"><X size={16} className="mr-1" /> Denied</span>;
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Access Requests</h1>
        <div className="flex space-x-2">
          {['pending', 'approved', 'denied', 'all'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg capitalize transition ${
                filter === f ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {requests.map((request) => (
          <div key={request.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex justify-between items-start">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <ClipboardList className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">
                    {request.requester?.full_name} ({request.requester?.role})
                  </h3>
                  <p className="text-sm text-gray-500">
                    Requesting access to: {request.patient?.user?.full_name || `Patient #${request.patient_id}`}
                  </p>
                  <p className="text-gray-600 mt-2">
                    <span className="font-medium">Reason:</span> {request.reason}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">
                    Requested: {new Date(request.requested_at).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                {getStatusBadge(request.status)}
                {user?.role === 'admin' && request.status === 'pending' && (
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleApprove(request.id)}
                      className="flex items-center space-x-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                    >
                      <Check size={18} />
                      <span>Approve</span>
                    </button>
                    <button
                      onClick={() => handleDeny(request.id)}
                      className="flex items-center space-x-1 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
                    >
                      <X size={18} />
                      <span>Deny</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {requests.length === 0 && (
          <div className="text-center py-12 text-gray-500 bg-white rounded-xl">
            No access requests found
          </div>
        )}
      </div>
    </div>
  );
}
