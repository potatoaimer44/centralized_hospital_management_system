import { useEffect, useState } from 'react';
import { aiService } from '../services/api';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { AlertTriangle, Shield, CheckCircle, Clock } from 'lucide-react';

interface SecurityAlert {
  id: number;
  alert_type: string;
  severity: string;
  user_id: number;
  user_name?: string;
  description: string;
  anomaly_score: number;
  is_resolved: boolean;
  created_at: string;
  resolved_at?: string;
}

export default function SecurityAlertsPage() {
  const [alerts, setAlerts] = useState<SecurityAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unresolved' | 'resolved'>('unresolved');

  useEffect(() => {
    loadAlerts();
  }, [filter]);

  const loadAlerts = async () => {
    try {
      const response = await aiService.getSecurityAlerts({
        is_resolved: filter === 'all' ? undefined : filter === 'resolved',
      });
      setAlerts(response.data.alerts);
    } catch (error) {
      console.error('Failed to load alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleResolve = async (alertId: number) => {
    try {
      await aiService.resolveAlert(alertId);
      loadAlerts();
    } catch (error: any) {
      alert(error.response?.data?.error || 'Failed to resolve alert');
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
      case 'high':
        return <AlertTriangle className="w-5 h-5" />;
      default:
        return <Shield className="w-5 h-5" />;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Security Alerts</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setFilter('unresolved')}
            className={`px-4 py-2 rounded-lg transition ${
              filter === 'unresolved' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Unresolved
          </button>
          <button
            onClick={() => setFilter('resolved')}
            className={`px-4 py-2 rounded-lg transition ${
              filter === 'resolved' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Resolved
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg transition ${
              filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`bg-white rounded-xl shadow-sm p-6 border ${
              alert.is_resolved ? 'border-gray-100' : 'border-l-4 border-l-red-500'
            }`}
          >
            <div className="flex justify-between items-start">
              <div className="flex items-start space-x-4">
                <div className={`p-2 rounded-lg ${getSeverityColor(alert.severity)}`}>
                  {getSeverityIcon(alert.severity)}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold text-gray-800">{alert.alert_type.replace(/_/g, ' ')}</h3>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${getSeverityColor(alert.severity)}`}>
                      {alert.severity.toUpperCase()}
                    </span>
                    {alert.is_resolved && (
                      <span className="px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700">
                        RESOLVED
                      </span>
                    )}
                  </div>
                  <p className="text-gray-600 mt-1">{alert.description}</p>
                  <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                    <span className="flex items-center">
                      <Clock size={14} className="mr-1" />
                      {new Date(alert.created_at).toLocaleString()}
                    </span>
                    {alert.user_name && (
                      <span>User: {alert.user_name}</span>
                    )}
                    <span>Score: {(alert.anomaly_score * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
              {!alert.is_resolved && (
                <button
                  onClick={() => handleResolve(alert.id)}
                  className="flex items-center space-x-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                >
                  <CheckCircle size={18} />
                  <span>Resolve</span>
                </button>
              )}
            </div>
          </div>
        ))}
        {alerts.length === 0 && (
          <div className="text-center py-12 text-gray-500 bg-white rounded-xl">
            <Shield className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>No security alerts found</p>
          </div>
        )}
      </div>
    </div>
  );
}
