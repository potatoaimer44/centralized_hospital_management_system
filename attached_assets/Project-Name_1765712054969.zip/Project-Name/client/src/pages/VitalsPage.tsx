import { useEffect, useState } from 'react';
import { vitalService, recordService } from '../services/api';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { Plus, Activity, X } from 'lucide-react';

interface VitalSign {
  id: number;
  medical_record_id: number;
  temperature: number;
  blood_pressure: string;
  pulse_rate: number;
  respiratory_rate: number;
  weight: number;
  height: number;
  bmi: number;
  recorded_at: string;
}

interface MedicalRecord {
  id: number;
  patient?: {
    user?: {
      full_name: string;
    };
  };
}

export default function VitalsPage() {
  const [vitals, setVitals] = useState<VitalSign[]>([]);
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    medical_record_id: '',
    temperature: '',
    blood_pressure: '',
    pulse_rate: '',
    respiratory_rate: '',
    weight: '',
    height: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [vitalsRes, recordsRes] = await Promise.all([
        vitalService.getAll(),
        recordService.getAll(),
      ]);
      setVitals(vitalsRes.data);
      setRecords(recordsRes.data.records);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await vitalService.create({
        ...formData,
        medical_record_id: parseInt(formData.medical_record_id),
        temperature: formData.temperature ? parseFloat(formData.temperature) : null,
        pulse_rate: formData.pulse_rate ? parseInt(formData.pulse_rate) : null,
        respiratory_rate: formData.respiratory_rate ? parseInt(formData.respiratory_rate) : null,
        weight: formData.weight ? parseFloat(formData.weight) : null,
        height: formData.height ? parseFloat(formData.height) : null,
      });
      setShowModal(false);
      loadData();
      setFormData({
        medical_record_id: '',
        temperature: '',
        blood_pressure: '',
        pulse_rate: '',
        respiratory_rate: '',
        weight: '',
        height: '',
      });
    } catch (error: any) {
      alert(error.response?.data?.error || 'Failed to record vitals');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Vital Signs</h1>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
        >
          <Plus size={20} />
          <span>Record Vitals</span>
        </button>
      </div>

      <div className="grid gap-4">
        {vitals.map((vital) => (
          <div key={vital.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Activity className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-gray-800">Record #{vital.medical_record_id}</h3>
                    <p className="text-sm text-gray-500">
                      {new Date(vital.recorded_at).toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                  <div>
                    <p className="text-sm text-gray-500">Temperature</p>
                    <p className="font-medium">{vital.temperature ? `${vital.temperature}°C` : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Blood Pressure</p>
                    <p className="font-medium">{vital.blood_pressure || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Pulse Rate</p>
                    <p className="font-medium">{vital.pulse_rate ? `${vital.pulse_rate} bpm` : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Respiratory Rate</p>
                    <p className="font-medium">{vital.respiratory_rate ? `${vital.respiratory_rate}/min` : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Weight</p>
                    <p className="font-medium">{vital.weight ? `${vital.weight} kg` : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Height</p>
                    <p className="font-medium">{vital.height ? `${vital.height} cm` : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">BMI</p>
                    <p className="font-medium">{vital.bmi ? vital.bmi.toFixed(1) : 'N/A'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
        {vitals.length === 0 && (
          <div className="text-center py-12 text-gray-500 bg-white rounded-xl">
            No vital signs recorded
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">Record Vital Signs</h2>
              <button onClick={() => setShowModal(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Medical Record</label>
                <select
                  value={formData.medical_record_id}
                  onChange={(e) => setFormData({ ...formData, medical_record_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                >
                  <option value="">Select Record</option>
                  {records.map((r) => (
                    <option key={r.id} value={r.id}>
                      Record #{r.id} - {r.patient?.user?.full_name || 'Patient'}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Temperature (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.temperature}
                    onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Blood Pressure</label>
                  <input
                    type="text"
                    placeholder="120/80"
                    value={formData.blood_pressure}
                    onChange={(e) => setFormData({ ...formData, blood_pressure: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Pulse Rate (bpm)</label>
                  <input
                    type="number"
                    value={formData.pulse_rate}
                    onChange={(e) => setFormData({ ...formData, pulse_rate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Respiratory Rate</label>
                  <input
                    type="number"
                    value={formData.respiratory_rate}
                    onChange={(e) => setFormData({ ...formData, respiratory_rate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.weight}
                    onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Height (cm)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.height}
                    onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Record Vitals
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
