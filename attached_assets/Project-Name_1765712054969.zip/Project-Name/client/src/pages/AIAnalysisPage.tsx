import { useState } from 'react';
import { aiService } from '../services/api';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { Brain, Search, Users, AlertTriangle, CheckCircle, X } from 'lucide-react';

interface Match {
  patient_id_1: number;
  patient_id_2: number;
  match_score: number;
  patient1_name?: string;
  patient2_name?: string;
  status?: string;
}

export default function AIAnalysisPage() {
  const [analyzing, setAnalyzing] = useState(false);
  const [matching, setMatching] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [matchResult, setMatchResult] = useState<Match[]>([]);

  const handleAnalyzeLogs = async () => {
    setAnalyzing(true);
    setAnalysisResult(null);
    try {
      const response = await aiService.analyzeLogs(7);
      setAnalysisResult(response.data);
    } catch (error: any) {
      alert(error.response?.data?.error || 'Failed to analyze logs');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleMatchRecords = async () => {
    setMatching(true);
    setMatchResult([]);
    try {
      const response = await aiService.matchRecords();
      setMatchResult(response.data.matches || []);
    } catch (error: any) {
      alert(error.response?.data?.error || 'Failed to match records');
    } finally {
      setMatching(false);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">AI Analysis</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Brain className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-800">Audit Log Analysis</h2>
              <p className="text-sm text-gray-500">Detect anomalies in user access patterns</p>
            </div>
          </div>
          <p className="text-gray-600 mb-4">
            Uses machine learning (Isolation Forest) to identify unusual access patterns in audit logs
            that may indicate security threats or policy violations.
          </p>
          <button
            onClick={handleAnalyzeLogs}
            disabled={analyzing}
            className="w-full flex items-center justify-center space-x-2 bg-purple-600 text-white px-4 py-3 rounded-lg hover:bg-purple-700 transition disabled:opacity-50"
          >
            {analyzing ? (
              <>
                <LoadingSpinner size="sm" />
                <span>Analyzing...</span>
              </>
            ) : (
              <>
                <Search size={20} />
                <span>Analyze Last 7 Days</span>
              </>
            )}
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-800">Record Matching</h2>
              <p className="text-sm text-gray-500">Find potential duplicate patient records</p>
            </div>
          </div>
          <p className="text-gray-600 mb-4">
            Uses fuzzy matching algorithms (Levenshtein distance) to identify patients who may have
            duplicate records across different hospitals.
          </p>
          <button
            onClick={handleMatchRecords}
            disabled={matching}
            className="w-full flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
          >
            {matching ? (
              <>
                <LoadingSpinner size="sm" />
                <span>Matching...</span>
              </>
            ) : (
              <>
                <Users size={20} />
                <span>Find Duplicates</span>
              </>
            )}
          </button>
        </div>
      </div>

      {analysisResult && (
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 mb-6">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-orange-500" />
            <span>Audit Log Analysis Results</span>
          </h3>
          <p className="text-gray-600 mb-4">{analysisResult.message}</p>
          {analysisResult.alerts && analysisResult.alerts.length > 0 ? (
            <div className="space-y-3">
              {analysisResult.alerts.map((alert: any, index: number) => (
                <div key={index} className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-red-800">{alert.description}</p>
                      <p className="text-sm text-red-600 mt-1">
                        Severity: {alert.severity} | Score: {(alert.anomaly_score * 100).toFixed(1)}%
                      </p>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      alert.severity === 'critical' ? 'bg-red-200 text-red-800' :
                      alert.severity === 'high' ? 'bg-orange-200 text-orange-800' :
                      'bg-yellow-200 text-yellow-800'
                    }`}>
                      {alert.severity.toUpperCase()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center space-x-2 text-green-600">
              <CheckCircle size={20} />
              <span>No anomalies detected</span>
            </div>
          )}
        </div>
      )}

      {matchResult.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <Users className="w-5 h-5 text-blue-500" />
            <span>Potential Duplicate Records</span>
          </h3>
          <div className="space-y-3">
            {matchResult.map((match, index) => (
              <div key={index} className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium text-blue-800">
                      {match.patient1_name || `Patient #${match.patient_id_1}`} 
                      {' '}↔{' '}
                      {match.patient2_name || `Patient #${match.patient_id_2}`}
                    </p>
                    <p className="text-sm text-blue-600 mt-1">
                      Match Score: {(match.match_score * 100).toFixed(1)}%
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 text-sm">
                      Confirm
                    </button>
                    <button className="px-3 py-1 bg-gray-600 text-white rounded hover:bg-gray-700 text-sm">
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
