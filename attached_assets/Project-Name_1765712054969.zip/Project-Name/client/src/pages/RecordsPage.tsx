import { useEffect, useState } from 'react';
import { recordService, patientService } from '../services/api';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { Plus, Eye, FileText, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface MedicalRecord {
  id: number;
  patient_id: number;
  doctor_id: number;
  hospital_id: number;
  visit_date: string;
  chief_complaint: string;
  diagnosis: string;
  prescription: string;
  lab_results: string;
  treatment_plan: string;
  notes: string;
  patient?: {
    user?: {
      full_name: string;
    };
  };
  doctor?: {
    full_name: string;
  };
  hospital?: {
    name: string;
  };
}

interface Patient {
  id: number;
  user: {
    full_name: string;
  };
}

export default function RecordsPage() {
  const { user } = useAuth();
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord | null>(null);
  const [formData, setFormData] = useState({
    patient_id: '',
    chief_complaint: '',
    diagnosis: '',
    prescription: '',
    lab_results: '',
    treatment_plan: '',
    notes: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [recordsRes, patientsRes] = await Promise.all([
        recordService.getAll(),
        user?.role !== 'patient' ? patientService.getAll() : Promise.resolve({ data: { patients: [] } }),
      ]);
      setRecords(recordsRes.data.records);
      setPatients(patientsRes.data.patients);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await recordService.create({
        ...formData,
        patient_id: parseInt(formData.patient_id),
      });
      setShowModal(false);
      loadData();
      setFormData({
        patient_id: '',
        chief_complaint: '',
        diagnosis: '',
        prescription: '',
        lab_results: '',
        treatment_plan: '',
        notes: '',
      });
    } catch (error: any) {
      alert(error.response?.data?.error || 'Failed to create record');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Medical Records</h1>
        {user?.role === 'doctor' && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
          >
            <Plus size={20} />
            <span>New Record</span>
          </button>
        )}
      </div>

      <div className="grid gap-4">
        {records.map((record) => (
          <div key={record.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex justify-between items-start">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">
                    {record.patient?.user?.full_name || `Patient #${record.patient_id}`}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {new Date(record.visit_date).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                    })}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    Dr. {record.doctor?.full_name} • {record.hospital?.name}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedRecord(record)}
                className="flex items-center space-x-1 text-blue-600 hover:text-blue-700"
              >
                <Eye size={18} />
                <span>View</span>
              </button>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-100">
              <p className="text-sm text-gray-600">
                <span className="font-medium">Chief Complaint:</span> {record.chief_complaint || 'N/A'}
              </p>
              <p className="text-sm text-gray-600 mt-1">
                <span className="font-medium">Diagnosis:</span> {record.diagnosis || 'N/A'}
              </p>
            </div>
          </div>
        ))}
        {records.length === 0 && (
          <div className="text-center py-12 text-gray-500 bg-white rounded-xl">
            No medical records found
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">New Medical Record</h2>
              <button onClick={() => setShowModal(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Patient</label>
                <select
                  value={formData.patient_id}
                  onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                >
                  <option value="">Select Patient</option>
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>{p.user?.full_name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Chief Complaint</label>
                <textarea
                  value={formData.chief_complaint}
                  onChange={(e) => setFormData({ ...formData, chief_complaint: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  rows={2}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Diagnosis</label>
                <textarea
                  value={formData.diagnosis}
                  onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  rows={2}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prescription</label>
                <textarea
                  value={formData.prescription}
                  onChange={(e) => setFormData({ ...formData, prescription: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  rows={2}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Lab Results</label>
                <textarea
                  value={formData.lab_results}
                  onChange={(e) => setFormData({ ...formData, lab_results: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  rows={2}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Treatment Plan</label>
                <textarea
                  value={formData.treatment_plan}
                  onChange={(e) => setFormData({ ...formData, treatment_plan: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  rows={2}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  rows={2}
                />
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Create Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selectedRecord && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">Medical Record Details</h2>
              <button onClick={() => setSelectedRecord(null)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Patient</p>
                  <p className="font-medium">{selectedRecord.patient?.user?.full_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Visit Date</p>
                  <p className="font-medium">{new Date(selectedRecord.visit_date).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Doctor</p>
                  <p className="font-medium">{selectedRecord.doctor?.full_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Hospital</p>
                  <p className="font-medium">{selectedRecord.hospital?.name}</p>
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500">Chief Complaint</p>
                <p className="font-medium">{selectedRecord.chief_complaint || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Diagnosis</p>
                <p className="font-medium">{selectedRecord.diagnosis || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Prescription</p>
                <p className="font-medium whitespace-pre-wrap">{selectedRecord.prescription || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Lab Results</p>
                <p className="font-medium whitespace-pre-wrap">{selectedRecord.lab_results || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Treatment Plan</p>
                <p className="font-medium whitespace-pre-wrap">{selectedRecord.treatment_plan || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Notes</p>
                <p className="font-medium whitespace-pre-wrap">{selectedRecord.notes || 'N/A'}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
