import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { dashboardService } from '../services/api';
import LoadingSpinner from '../components/common/LoadingSpinner';
import {
  Users,
  UserCheck,
  Building2,
  FileText,
  ClipboardList,
  AlertTriangle,
  Activity,
  Calendar,
} from 'lucide-react';

interface Stats {
  total_patients?: number;
  total_doctors?: number;
  total_nurses?: number;
  total_hospitals?: number;
  total_records?: number;
  pending_requests?: number;
  unresolved_alerts?: number;
  records_this_week?: number;
  my_patients?: number;
  my_records?: number;
  records_today?: number;
  recent_visits?: number;
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stats>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const response = await dashboardService.getStats();
      setStats(response.data);
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const StatCard = ({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number | undefined; color: string }) => (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center space-x-4">
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${color}`}>
          {icon}
        </div>
        <div>
          <p className="text-gray-500 text-sm">{label}</p>
          <p className="text-2xl font-bold text-gray-800">{value ?? 0}</p>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800">
          {getGreeting()}, {user?.full_name}
        </h1>
        <p className="text-gray-500 mt-1">
          {user?.hospital?.name && `${user.hospital.name} • `}
          {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </div>

      {user?.role === 'admin' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            icon={<Users className="w-6 h-6 text-blue-600" />}
            label="Total Patients"
            value={stats.total_patients}
            color="bg-blue-100"
          />
          <StatCard
            icon={<UserCheck className="w-6 h-6 text-green-600" />}
            label="Total Doctors"
            value={stats.total_doctors}
            color="bg-green-100"
          />
          <StatCard
            icon={<Building2 className="w-6 h-6 text-purple-600" />}
            label="Hospitals"
            value={stats.total_hospitals}
            color="bg-purple-100"
          />
          <StatCard
            icon={<FileText className="w-6 h-6 text-orange-600" />}
            label="Medical Records"
            value={stats.total_records}
            color="bg-orange-100"
          />
          <StatCard
            icon={<ClipboardList className="w-6 h-6 text-yellow-600" />}
            label="Pending Requests"
            value={stats.pending_requests}
            color="bg-yellow-100"
          />
          <StatCard
            icon={<AlertTriangle className="w-6 h-6 text-red-600" />}
            label="Unresolved Alerts"
            value={stats.unresolved_alerts}
            color="bg-red-100"
          />
          <StatCard
            icon={<Activity className="w-6 h-6 text-cyan-600" />}
            label="Records This Week"
            value={stats.records_this_week}
            color="bg-cyan-100"
          />
          <StatCard
            icon={<Users className="w-6 h-6 text-indigo-600" />}
            label="Total Nurses"
            value={stats.total_nurses}
            color="bg-indigo-100"
          />
        </div>
      )}

      {user?.role === 'doctor' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            icon={<Users className="w-6 h-6 text-blue-600" />}
            label="My Patients"
            value={stats.my_patients}
            color="bg-blue-100"
          />
          <StatCard
            icon={<FileText className="w-6 h-6 text-green-600" />}
            label="My Records"
            value={stats.my_records}
            color="bg-green-100"
          />
          <StatCard
            icon={<Calendar className="w-6 h-6 text-purple-600" />}
            label="Records Today"
            value={stats.records_today}
            color="bg-purple-100"
          />
          <StatCard
            icon={<ClipboardList className="w-6 h-6 text-orange-600" />}
            label="Pending Requests"
            value={stats.pending_requests}
            color="bg-orange-100"
          />
        </div>
      )}

      {user?.role === 'nurse' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <StatCard
            icon={<Users className="w-6 h-6 text-blue-600" />}
            label="Total Patients"
            value={stats.total_patients}
            color="bg-blue-100"
          />
        </div>
      )}

      {user?.role === 'patient' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <StatCard
            icon={<FileText className="w-6 h-6 text-blue-600" />}
            label="My Medical Records"
            value={stats.my_records}
            color="bg-blue-100"
          />
          <StatCard
            icon={<Calendar className="w-6 h-6 text-green-600" />}
            label="Recent Visits"
            value={stats.recent_visits}
            color="bg-green-100"
          />
        </div>
      )}

      <div className="mt-8 bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {user?.role === 'doctor' && (
            <>
              <a href="/patients" className="p-4 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition">
                <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-gray-700">View Patients</span>
              </a>
              <a href="/records" className="p-4 bg-green-50 rounded-lg text-center hover:bg-green-100 transition">
                <FileText className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-gray-700">Medical Records</span>
              </a>
            </>
          )}
          {user?.role === 'admin' && (
            <>
              <a href="/users" className="p-4 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition">
                <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-gray-700">Manage Users</span>
              </a>
              <a href="/security-alerts" className="p-4 bg-red-50 rounded-lg text-center hover:bg-red-100 transition">
                <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-gray-700">Security Alerts</span>
              </a>
              <a href="/ai-analysis" className="p-4 bg-purple-50 rounded-lg text-center hover:bg-purple-100 transition">
                <Activity className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-gray-700">AI Analysis</span>
              </a>
            </>
          )}
          {user?.role === 'patient' && (
            <a href="/records" className="p-4 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition">
              <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <span className="text-sm font-medium text-gray-700">My Records</span>
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
