import { useEffect, useState } from 'react';
import { auditService } from '../services/api';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { Eye, Clock, User } from 'lucide-react';

interface AccessLog {
  id: number;
  action: string;
  timestamp: string;
  accessed_by?: {
    name: string;
    role: string;
  };
}

export default function MyAccessPage() {
  const [logs, setLogs] = useState<AccessLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    try {
      const response = await auditService.getMyAccess();
      setLogs(response.data.logs);
    } catch (error) {
      console.error('Failed to load logs:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">My Access Log</h1>
        <p className="text-gray-500 mt-1">See who has accessed your medical records</p>
      </div>

      <div className="space-y-4">
        {logs.map((log) => (
          <div key={log.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Eye className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-gray-800">
                      {log.action.replace(/_/g, ' ')}
                    </h3>
                    {log.accessed_by && (
                      <div className="flex items-center space-x-2 mt-1">
                        <User size={16} className="text-gray-400" />
                        <span className="text-gray-600">
                          {log.accessed_by.name} ({log.accessed_by.role})
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock size={16} className="mr-1" />
                    {new Date(log.timestamp).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
        {logs.length === 0 && (
          <div className="text-center py-12 text-gray-500 bg-white rounded-xl">
            <Eye className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>No access logs found</p>
            <p className="text-sm mt-1">Your records haven't been accessed yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
