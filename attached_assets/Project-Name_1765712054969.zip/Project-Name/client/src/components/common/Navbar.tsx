import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { LogOut, User, Menu } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const [showMenu, setShowMenu] = useState(false);

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16 items-center">
          <Link to="/dashboard" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <span className="text-blue-600 font-bold text-lg">M</span>
            </div>
            <span className="font-bold text-xl">MedRec</span>
          </Link>

          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <User size={20} />
              <span>{user?.full_name}</span>
              <span className="px-2 py-1 bg-blue-500 rounded text-sm capitalize">{user?.role}</span>
            </div>
            <button
              onClick={logout}
              className="flex items-center space-x-1 px-3 py-2 rounded hover:bg-blue-700 transition"
            >
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>

          <button
            className="md:hidden"
            onClick={() => setShowMenu(!showMenu)}
          >
            <Menu size={24} />
          </button>
        </div>
      </div>

      {showMenu && (
        <div className="md:hidden px-4 pb-4">
          <div className="flex items-center space-x-2 py-2">
            <User size={20} />
            <span>{user?.full_name}</span>
          </div>
          <button
            onClick={logout}
            className="flex items-center space-x-1 w-full px-3 py-2 rounded hover:bg-blue-700 transition"
          >
            <LogOut size={18} />
            <span>Logout</span>
          </button>
        </div>
      )}
    </nav>
  );
}
