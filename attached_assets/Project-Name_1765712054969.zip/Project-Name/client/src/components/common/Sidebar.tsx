import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard,
  Users,
  Building2,
  FileText,
  Activity,
  Shield,
  Brain,
  ClipboardList,
  History,
  UserCircle,
} from 'lucide-react';

interface NavItem {
  label: string;
  path: string;
  icon: React.ReactNode;
  roles: string[];
}

const navItems: NavItem[] = [
  { label: 'Dashboard', path: '/dashboard', icon: <LayoutDashboard size={20} />, roles: ['admin', 'doctor', 'nurse', 'patient'] },
  { label: 'Hospitals', path: '/hospitals', icon: <Building2 size={20} />, roles: ['admin'] },
  { label: 'Users', path: '/users', icon: <Users size={20} />, roles: ['admin'] },
  { label: 'Patients', path: '/patients', icon: <UserCircle size={20} />, roles: ['admin', 'doctor', 'nurse'] },
  { label: 'Medical Records', path: '/records', icon: <FileText size={20} />, roles: ['admin', 'doctor', 'nurse', 'patient'] },
  { label: 'Vital Signs', path: '/vitals', icon: <Activity size={20} />, roles: ['doctor', 'nurse'] },
  { label: 'Access Requests', path: '/access-requests', icon: <ClipboardList size={20} />, roles: ['admin', 'doctor', 'nurse'] },
  { label: 'Audit Logs', path: '/audit-logs', icon: <History size={20} />, roles: ['admin'] },
  { label: 'Security Alerts', path: '/security-alerts', icon: <Shield size={20} />, roles: ['admin'] },
  { label: 'AI Analysis', path: '/ai-analysis', icon: <Brain size={20} />, roles: ['admin'] },
  { label: 'My Access Log', path: '/my-access', icon: <History size={20} />, roles: ['patient'] },
];

export default function Sidebar() {
  const { user } = useAuth();
  const location = useLocation();

  const filteredItems = navItems.filter(item => 
    user && item.roles.includes(user.role)
  );

  return (
    <aside className="w-64 bg-white shadow-md min-h-screen">
      <nav className="p-4">
        <ul className="space-y-2">
          {filteredItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition ${
                  location.pathname === item.path
                    ? 'bg-blue-50 text-blue-600 font-medium'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}
