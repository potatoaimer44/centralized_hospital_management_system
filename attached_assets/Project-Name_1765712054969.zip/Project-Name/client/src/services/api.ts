import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authService = {
  login: (username: string, password: string) => 
    api.post('/auth/login', { username, password }),
  register: (data: any) => api.post('/auth/register', data),
  me: () => api.get('/auth/me'),
  changePassword: (currentPassword: string, newPassword: string) =>
    api.put('/auth/change-password', { current_password: currentPassword, new_password: newPassword }),
};

export const hospitalService = {
  getAll: () => api.get('/hospitals'),
  getById: (id: number) => api.get(`/hospitals/${id}`),
  create: (data: any) => api.post('/hospitals', data),
  update: (id: number, data: any) => api.put(`/hospitals/${id}`, data),
};

export const userService = {
  getAll: (params?: any) => api.get('/users', { params }),
  getById: (id: number) => api.get(`/users/${id}`),
  create: (data: any) => api.post('/users', data),
  update: (id: number, data: any) => api.put(`/users/${id}`, data),
  deactivate: (id: number) => api.delete(`/users/${id}`),
};

export const patientService = {
  getAll: (params?: any) => api.get('/patients', { params }),
  getById: (id: number) => api.get(`/patients/${id}`),
  create: (data: any) => api.post('/patients', data),
  update: (id: number, data: any) => api.put(`/patients/${id}`, data),
  search: (query: string) => api.get('/patients/search', { params: { q: query } }),
  getHistory: (id: number) => api.get(`/patients/${id}/history`),
};

export const recordService = {
  getAll: (params?: any) => api.get('/records', { params }),
  getById: (id: number) => api.get(`/records/${id}`),
  create: (data: any) => api.post('/records', data),
  update: (id: number, data: any) => api.put(`/records/${id}`, data),
  delete: (id: number) => api.delete(`/records/${id}`),
};

export const vitalService = {
  getAll: (params?: any) => api.get('/vitals', { params }),
  create: (data: any) => api.post('/vitals', data),
};

export const auditService = {
  getLogs: (params?: any) => api.get('/audit-logs', { params }),
  getMyAccess: (params?: any) => api.get('/audit-logs/my-access', { params }),
  getStats: () => api.get('/audit-logs/stats'),
};

export const accessRequestService = {
  getAll: (params?: any) => api.get('/access-requests', { params }),
  create: (data: any) => api.post('/access-requests', data),
  approve: (id: number) => api.put(`/access-requests/${id}/approve`),
  deny: (id: number) => api.put(`/access-requests/${id}/deny`),
};

export const aiService = {
  analyzeLogs: (days?: number) => api.post('/ai/analyze-logs', null, { params: { days } }),
  getSecurityAlerts: (params?: any) => api.get('/ai/security-alerts', { params }),
  resolveAlert: (id: number) => api.put(`/ai/security-alerts/${id}/resolve`),
  matchRecords: () => api.post('/ai/match-records'),
  getRecordMatches: (params?: any) => api.get('/ai/record-matches', { params }),
  confirmMatch: (id: number, status: string) => api.put(`/ai/confirm-match/${id}`, { status }),
};

export const dashboardService = {
  getStats: () => api.get('/dashboard/stats'),
  getRecentActivity: () => api.get('/dashboard/recent-activity'),
};

export default api;
