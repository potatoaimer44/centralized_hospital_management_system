# Medical Records Management System

## Overview
A secure, centralized web-based medical record management system for teenagers in Kathmandu Valley with AI-driven audit log analysis and record matching capabilities.

## Tech Stack
- **Frontend**: React + TypeScript + Tailwind CSS + Vite
- **Backend**: Python Flask with Flask-SQLAlchemy, Flask-JWT-Extended
- **Database**: PostgreSQL
- **AI/ML**: scikit-learn (Isolation Forest for anomaly detection), fuzzywuzzy (record matching)

## Project Structure
```
├── backend/
│   ├── app.py              # Main Flask application
│   ├── config.py           # Configuration
│   ├── models/             # SQLAlchemy models
│   ├── routes/             # API endpoints
│   ├── services/           # AI services
│   └── utils/              # Utilities
├── client/
│   └── src/
│       ├── components/     # React components
│       ├── pages/          # Page components
│       ├── context/        # Auth context
│       └── services/       # API services
```

## Running the Application
- Backend runs on port 5001
- Frontend runs on port 5000 (proxies to backend)

## Demo Accounts
- Admin: admin / admin123
- Doctor: dr_sharma / doctor123
- Nurse: nurse_maya / nurse123

## Key Features
- Role-based access control (Admin, Doctor, Nurse, Patient)
- Patient management with medical records
- Vital signs recording
- Audit logging with AI anomaly detection
- Duplicate record matching using fuzzy algorithms
- Security alerts management
