import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from backend.models import db
from backend.config import Config

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    db.init_app(app)
    jwt = JWTManager(app)
    
    from backend.routes.auth import auth_bp
    from backend.routes.users import users_bp
    from backend.routes.hospitals import hospitals_bp
    from backend.routes.patients import patients_bp
    from backend.routes.records import records_bp
    from backend.routes.vitals import vitals_bp
    from backend.routes.audit import audit_bp
    from backend.routes.access_requests import access_requests_bp
    from backend.routes.ai import ai_bp
    from backend.routes.dashboard import dashboard_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(users_bp, url_prefix='/api/users')
    app.register_blueprint(hospitals_bp, url_prefix='/api/hospitals')
    app.register_blueprint(patients_bp, url_prefix='/api/patients')
    app.register_blueprint(records_bp, url_prefix='/api/records')
    app.register_blueprint(vitals_bp, url_prefix='/api/vitals')
    app.register_blueprint(audit_bp, url_prefix='/api/audit-logs')
    app.register_blueprint(access_requests_bp, url_prefix='/api/access-requests')
    app.register_blueprint(ai_bp, url_prefix='/api/ai')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    
    @app.route('/api/health')
    def health():
        return jsonify({'status': 'healthy'})
    
    with app.app_context():
        db.create_all()
        seed_initial_data()
    
    return app

def seed_initial_data():
    from backend.models.user import User
    from backend.models.hospital import Hospital
    
    if Hospital.query.first() is None:
        hospitals = [
            Hospital(name='Tribhuvan University Teaching Hospital', address='Maharajgunj, Kathmandu', district='Kathmandu', phone='01-4412303', email='tuth@tuth.org.np'),
            Hospital(name='Bir Hospital', address='Mahabouddha, Kathmandu', district='Kathmandu', phone='01-4221119', email='info@birhospital.org.np'),
            Hospital(name='Patan Hospital', address='Lagankhel, Lalitpur', district='Lalitpur', phone='01-5522266', email='info@patanhospital.org.np'),
            Hospital(name='Nepal Medical College', address='Jorpati, Kathmandu', district='Kathmandu', phone='01-4912040', email='info@nmcth.edu'),
            Hospital(name='Grande International Hospital', address='Dhapasi, Kathmandu', district='Kathmandu', phone='01-5159266', email='info@grandehospital.com')
        ]
        for hospital in hospitals:
            db.session.add(hospital)
        db.session.commit()
    
    if User.query.filter_by(role='admin').first() is None:
        admin = User(
            username='admin',
            email='admin@medrec.np',
            full_name='System Administrator',
            role='admin',
            hospital_id=1,
            phone='9841000001'
        )
        admin.set_password('admin123')
        db.session.add(admin)
        
        doctor = User(
            username='dr_sharma',
            email='dr.sharma@medrec.np',
            full_name='Dr. Ram Sharma',
            role='doctor',
            hospital_id=1,
            phone='9841000002'
        )
        doctor.set_password('doctor123')
        db.session.add(doctor)
        
        nurse = User(
            username='nurse_maya',
            email='maya.nurse@medrec.np',
            full_name='Maya Tamang',
            role='nurse',
            hospital_id=1,
            phone='9841000003'
        )
        nurse.set_password('nurse123')
        db.session.add(nurse)
        
        db.session.commit()

app = create_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
