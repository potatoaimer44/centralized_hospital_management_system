from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.utils.decorators import role_required
from backend.utils.audit import log_action

users_bp = Blueprint('users', __name__)

@users_bp.route('/', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_users():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    role = request.args.get('role')
    hospital_id = request.args.get('hospital_id', type=int)
    
    query = User.query
    
    if role:
        query = query.filter_by(role=role)
    if hospital_id:
        query = query.filter_by(hospital_id=hospital_id)
    
    pagination = query.paginate(page=page, per_page=per_page)
    
    return jsonify({
        'users': [u.to_dict(include_hospital=True) for u in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@users_bp.route('/<int:user_id>', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict(include_hospital=True))

@users_bp.route('/', methods=['POST'])
@jwt_required()
@role_required('admin')
def create_user():
    data = request.get_json()
    
    if User.query.filter_by(username=data.get('username')).first():
        return jsonify({'error': 'Username already exists'}), 400
    
    if User.query.filter_by(email=data.get('email')).first():
        return jsonify({'error': 'Email already exists'}), 400
    
    user = User(
        username=data['username'],
        email=data['email'],
        full_name=data['full_name'],
        role=data['role'],
        hospital_id=data.get('hospital_id'),
        phone=data.get('phone')
    )
    user.set_password(data.get('password', 'changeme123'))
    
    db.session.add(user)
    db.session.commit()
    
    log_action('CREATE_USER', 'user', user.id)
    
    return jsonify(user.to_dict()), 201

@users_bp.route('/<int:user_id>', methods=['PUT'])
@jwt_required()
@role_required('admin')
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if data.get('email') and data['email'] != user.email:
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already exists'}), 400
        user.email = data['email']
    
    if data.get('full_name'):
        user.full_name = data['full_name']
    if data.get('phone'):
        user.phone = data['phone']
    if data.get('hospital_id'):
        user.hospital_id = data['hospital_id']
    if 'is_active' in data:
        user.is_active = data['is_active']
    
    db.session.commit()
    log_action('UPDATE_USER', 'user', user.id)
    
    return jsonify(user.to_dict())

@users_bp.route('/<int:user_id>', methods=['DELETE'])
@jwt_required()
@role_required('admin')
def deactivate_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_active = False
    db.session.commit()
    
    log_action('DEACTIVATE_USER', 'user', user.id)
    
    return jsonify({'message': 'User deactivated successfully'})
