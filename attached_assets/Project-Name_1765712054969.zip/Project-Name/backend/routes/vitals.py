from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.models.vital_signs import VitalSigns
from backend.models.medical_record import MedicalRecord
from backend.utils.decorators import role_required
from backend.utils.audit import log_action

vitals_bp = Blueprint('vitals', __name__)

@vitals_bp.route('/', methods=['GET'])
@jwt_required()
def get_vitals():
    medical_record_id = request.args.get('medical_record_id', type=int)
    
    query = VitalSigns.query
    
    if medical_record_id:
        query = query.filter_by(medical_record_id=medical_record_id)
    
    vitals = query.order_by(VitalSigns.recorded_at.desc()).all()
    
    return jsonify([v.to_dict() for v in vitals])

@vitals_bp.route('/<int:vital_id>', methods=['GET'])
@jwt_required()
def get_vital(vital_id):
    vital = VitalSigns.query.get_or_404(vital_id)
    return jsonify(vital.to_dict())

@vitals_bp.route('/', methods=['POST'])
@jwt_required()
@role_required('doctor', 'nurse')
def create_vital():
    user_id = get_jwt_identity()
    data = request.get_json()
    
    record = MedicalRecord.query.get(data['medical_record_id'])
    if not record:
        return jsonify({'error': 'Medical record not found'}), 404
    
    weight = float(data.get('weight', 0)) if data.get('weight') else None
    height = float(data.get('height', 0)) if data.get('height') else None
    bmi = None
    
    if weight and height:
        height_m = height / 100
        bmi = round(weight / (height_m * height_m), 2)
    
    vital = VitalSigns(
        medical_record_id=data['medical_record_id'],
        recorded_by=user_id,
        temperature=data.get('temperature'),
        blood_pressure=data.get('blood_pressure'),
        pulse_rate=data.get('pulse_rate'),
        respiratory_rate=data.get('respiratory_rate'),
        weight=weight,
        height=height,
        bmi=bmi
    )
    
    db.session.add(vital)
    db.session.commit()
    
    log_action('RECORD_VITALS', 'vital_signs', vital.id, patient_id=record.patient_id)
    
    return jsonify(vital.to_dict()), 201
