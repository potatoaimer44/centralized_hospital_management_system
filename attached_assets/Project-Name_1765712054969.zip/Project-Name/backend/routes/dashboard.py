from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.models.patient import Patient
from backend.models.hospital import Hospital
from backend.models.medical_record import MedicalRecord
from backend.models.security_alert import SecurityAlert
from backend.models.access_request import AccessRequest
from backend.utils.decorators import role_required
from sqlalchemy import func
from datetime import datetime, timedelta

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_dashboard_stats():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    stats = {}
    
    if user.role == 'admin':
        stats['total_patients'] = Patient.query.count()
        stats['total_doctors'] = User.query.filter_by(role='doctor').count()
        stats['total_nurses'] = User.query.filter_by(role='nurse').count()
        stats['total_hospitals'] = Hospital.query.count()
        stats['total_records'] = MedicalRecord.query.count()
        stats['pending_requests'] = AccessRequest.query.filter_by(status='pending').count()
        stats['unresolved_alerts'] = SecurityAlert.query.filter_by(is_resolved=False).count()
        
        today = datetime.utcnow().date()
        week_ago = today - timedelta(days=7)
        stats['records_this_week'] = MedicalRecord.query.filter(
            func.date(MedicalRecord.created_at) >= week_ago
        ).count()
        
    elif user.role == 'doctor':
        stats['my_patients'] = MedicalRecord.query.filter_by(doctor_id=user_id)\
            .with_entities(MedicalRecord.patient_id).distinct().count()
        stats['my_records'] = MedicalRecord.query.filter_by(doctor_id=user_id).count()
        stats['pending_requests'] = AccessRequest.query.filter_by(
            requester_id=user_id, status='pending'
        ).count()
        
        today = datetime.utcnow().date()
        stats['records_today'] = MedicalRecord.query.filter(
            MedicalRecord.doctor_id == user_id,
            func.date(MedicalRecord.created_at) == today
        ).count()
        
    elif user.role == 'nurse':
        stats['total_patients'] = Patient.query.count()
        
    elif user.role == 'patient':
        patient = Patient.query.filter_by(user_id=user_id).first()
        if patient:
            stats['my_records'] = MedicalRecord.query.filter_by(patient_id=patient.id).count()
            stats['recent_visits'] = MedicalRecord.query.filter_by(patient_id=patient.id)\
                .order_by(MedicalRecord.visit_date.desc()).limit(5).count()
    
    return jsonify(stats)

@dashboard_bp.route('/recent-activity', methods=['GET'])
@jwt_required()
def get_recent_activity():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    activity = []
    
    if user.role == 'admin':
        recent_records = MedicalRecord.query\
            .order_by(MedicalRecord.created_at.desc()).limit(10).all()
        
        for record in recent_records:
            activity.append({
                'type': 'record_created',
                'message': f'New medical record created for patient #{record.patient_id}',
                'timestamp': record.created_at.isoformat()
            })
    
    elif user.role == 'doctor':
        recent_records = MedicalRecord.query.filter_by(doctor_id=user_id)\
            .order_by(MedicalRecord.created_at.desc()).limit(10).all()
        
        for record in recent_records:
            activity.append({
                'type': 'record_created',
                'message': f'Medical record for patient #{record.patient_id}',
                'timestamp': record.created_at.isoformat()
            })
    
    elif user.role == 'patient':
        patient = Patient.query.filter_by(user_id=user_id).first()
        if patient:
            recent_records = MedicalRecord.query.filter_by(patient_id=patient.id)\
                .order_by(MedicalRecord.visit_date.desc()).limit(10).all()
            
            for record in recent_records:
                activity.append({
                    'type': 'visit',
                    'message': f'Visit at hospital #{record.hospital_id}',
                    'timestamp': record.visit_date.isoformat()
                })
    
    return jsonify(activity)
