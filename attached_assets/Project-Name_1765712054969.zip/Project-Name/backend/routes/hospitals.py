from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from backend.models import db
from backend.models.hospital import Hospital
from backend.utils.decorators import role_required
from backend.utils.audit import log_action

hospitals_bp = Blueprint('hospitals', __name__)

@hospitals_bp.route('/', methods=['GET'])
@jwt_required()
def get_hospitals():
    hospitals = Hospital.query.all()
    return jsonify([h.to_dict() for h in hospitals])

@hospitals_bp.route('/<int:hospital_id>', methods=['GET'])
@jwt_required()
def get_hospital(hospital_id):
    hospital = Hospital.query.get_or_404(hospital_id)
    return jsonify(hospital.to_dict())

@hospitals_bp.route('/', methods=['POST'])
@jwt_required()
@role_required('admin')
def create_hospital():
    data = request.get_json()
    
    hospital = Hospital(
        name=data['name'],
        address=data.get('address'),
        district=data.get('district', 'Kathmandu'),
        phone=data.get('phone'),
        email=data.get('email')
    )
    
    db.session.add(hospital)
    db.session.commit()
    
    log_action('CREATE_HOSPITAL', 'hospital', hospital.id)
    
    return jsonify(hospital.to_dict()), 201

@hospitals_bp.route('/<int:hospital_id>', methods=['PUT'])
@jwt_required()
@role_required('admin')
def update_hospital(hospital_id):
    hospital = Hospital.query.get_or_404(hospital_id)
    data = request.get_json()
    
    if data.get('name'):
        hospital.name = data['name']
    if data.get('address'):
        hospital.address = data['address']
    if data.get('district'):
        hospital.district = data['district']
    if data.get('phone'):
        hospital.phone = data['phone']
    if data.get('email'):
        hospital.email = data['email']
    
    db.session.commit()
    log_action('UPDATE_HOSPITAL', 'hospital', hospital.id)
    
    return jsonify(hospital.to_dict())
