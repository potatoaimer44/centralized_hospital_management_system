from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.models.patient import Patient
from backend.models.audit_log import AuditLog
from backend.utils.decorators import role_required
from sqlalchemy import func

audit_bp = Blueprint('audit', __name__)

@audit_bp.route('/', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_audit_logs():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    user_id = request.args.get('user_id', type=int)
    action = request.args.get('action')
    patient_id = request.args.get('patient_id', type=int)
    
    query = AuditLog.query
    
    if user_id:
        query = query.filter_by(user_id=user_id)
    if action:
        query = query.filter_by(action=action)
    if patient_id:
        query = query.filter_by(patient_id=patient_id)
    
    query = query.order_by(AuditLog.timestamp.desc())
    pagination = query.paginate(page=page, per_page=per_page)
    
    logs = []
    for log in pagination.items:
        log_dict = log.to_dict()
        if log.user:
            log_dict['user_name'] = log.user.full_name
        logs.append(log_dict)
    
    return jsonify({
        'logs': logs,
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@audit_bp.route('/my-access', methods=['GET'])
@jwt_required()
def get_my_access_logs():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if user.role != 'patient':
        return jsonify({'error': 'Only patients can view their access logs'}), 403
    
    patient = Patient.query.filter_by(user_id=user_id).first()
    if not patient:
        return jsonify({'logs': []})
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = AuditLog.query.filter_by(patient_id=patient.id)\
        .order_by(AuditLog.timestamp.desc())
    
    pagination = query.paginate(page=page, per_page=per_page)
    
    logs = []
    for log in pagination.items:
        log_dict = log.to_dict()
        if log.user:
            log_dict['accessed_by'] = {
                'name': log.user.full_name,
                'role': log.user.role
            }
        logs.append(log_dict)
    
    return jsonify({
        'logs': logs,
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@audit_bp.route('/stats', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_audit_stats():
    action_counts = db.session.query(
        AuditLog.action,
        func.count(AuditLog.id).label('count')
    ).group_by(AuditLog.action).all()
    
    user_activity = db.session.query(
        User.full_name,
        func.count(AuditLog.id).label('count')
    ).join(AuditLog).group_by(User.id).order_by(func.count(AuditLog.id).desc()).limit(10).all()
    
    return jsonify({
        'action_counts': [{'action': a[0], 'count': a[1]} for a in action_counts],
        'top_users': [{'name': u[0], 'count': u[1]} for u in user_activity]
    })
