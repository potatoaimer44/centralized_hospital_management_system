from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.models.patient import Patient
from backend.models.medical_record import MedicalRecord
from backend.utils.decorators import role_required
from backend.utils.audit import log_action
from datetime import datetime

patients_bp = Blueprint('patients', __name__)

@patients_bp.route('/', methods=['GET'])
@jwt_required()
def get_patients():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    search = request.args.get('search', '')
    
    query = Patient.query.join(User)
    
    if user.role == 'patient':
        query = query.filter(Patient.user_id == user_id)
    
    if search:
        query = query.filter(User.full_name.ilike(f'%{search}%'))
    
    pagination = query.paginate(page=page, per_page=per_page)
    
    return jsonify({
        'patients': [p.to_dict(include_user=True) for p in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@patients_bp.route('/<int:patient_id>', methods=['GET'])
@jwt_required()
def get_patient(patient_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    patient = Patient.query.get_or_404(patient_id)
    
    if user.role == 'patient' and patient.user_id != user_id:
        return jsonify({'error': 'Access denied'}), 403
    
    log_action('VIEW_PATIENT', 'patient', patient_id, patient_id=patient_id)
    
    return jsonify(patient.to_dict(include_user=True))

@patients_bp.route('/', methods=['POST'])
@jwt_required()
@role_required('admin', 'doctor', 'nurse')
def create_patient():
    data = request.get_json()
    
    user = User(
        username=data['username'],
        email=data['email'],
        full_name=data['full_name'],
        role='patient',
        hospital_id=data.get('hospital_id'),
        phone=data.get('phone')
    )
    user.set_password(data.get('password', 'patient123'))
    
    db.session.add(user)
    db.session.flush()
    
    patient = Patient(
        user_id=user.id,
        date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date(),
        gender=data.get('gender'),
        blood_group=data.get('blood_group'),
        address=data.get('address'),
        guardian_name=data.get('guardian_name'),
        guardian_phone=data.get('guardian_phone'),
        guardian_relation=data.get('guardian_relation'),
        emergency_contact=data.get('emergency_contact'),
        allergies=data.get('allergies')
    )
    
    db.session.add(patient)
    db.session.commit()
    
    log_action('CREATE_PATIENT', 'patient', patient.id, patient_id=patient.id)
    
    return jsonify(patient.to_dict(include_user=True)), 201

@patients_bp.route('/<int:patient_id>', methods=['PUT'])
@jwt_required()
def update_patient(patient_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    patient = Patient.query.get_or_404(patient_id)
    
    if user.role == 'patient' and patient.user_id != user_id:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json()
    
    if data.get('date_of_birth'):
        patient.date_of_birth = datetime.strptime(data['date_of_birth'], '%Y-%m-%d').date()
    if data.get('gender'):
        patient.gender = data['gender']
    if data.get('blood_group'):
        patient.blood_group = data['blood_group']
    if data.get('address'):
        patient.address = data['address']
    if data.get('guardian_name'):
        patient.guardian_name = data['guardian_name']
    if data.get('guardian_phone'):
        patient.guardian_phone = data['guardian_phone']
    if data.get('guardian_relation'):
        patient.guardian_relation = data['guardian_relation']
    if data.get('emergency_contact'):
        patient.emergency_contact = data['emergency_contact']
    if data.get('allergies'):
        patient.allergies = data['allergies']
    
    db.session.commit()
    log_action('UPDATE_PATIENT', 'patient', patient_id, patient_id=patient_id)
    
    return jsonify(patient.to_dict(include_user=True))

@patients_bp.route('/search', methods=['GET'])
@jwt_required()
@role_required('admin', 'doctor', 'nurse')
def search_patients():
    query_str = request.args.get('q', '')
    
    if len(query_str) < 2:
        return jsonify({'error': 'Search query must be at least 2 characters'}), 400
    
    patients = Patient.query.join(User).filter(
        db.or_(
            User.full_name.ilike(f'%{query_str}%'),
            User.email.ilike(f'%{query_str}%'),
            User.phone.ilike(f'%{query_str}%')
        )
    ).limit(20).all()
    
    return jsonify([p.to_dict(include_user=True) for p in patients])

@patients_bp.route('/<int:patient_id>/history', methods=['GET'])
@jwt_required()
def get_patient_history(patient_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    patient = Patient.query.get_or_404(patient_id)
    
    if user.role == 'patient' and patient.user_id != user_id:
        return jsonify({'error': 'Access denied'}), 403
    
    records = MedicalRecord.query.filter_by(patient_id=patient_id)\
        .order_by(MedicalRecord.visit_date.desc()).all()
    
    log_action('VIEW_PATIENT_HISTORY', 'patient', patient_id, patient_id=patient_id)
    
    return jsonify({
        'patient': patient.to_dict(include_user=True),
        'medical_records': [r.to_dict(include_relations=True) for r in records]
    })
