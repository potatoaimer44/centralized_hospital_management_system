from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.models.access_request import AccessRequest
from backend.utils.decorators import role_required
from backend.utils.audit import log_action
from datetime import datetime

access_requests_bp = Blueprint('access_requests', __name__)

@access_requests_bp.route('/', methods=['GET'])
@jwt_required()
def get_access_requests():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    
    query = AccessRequest.query
    
    if user.role != 'admin':
        query = query.filter_by(requester_id=user_id)
    
    if status:
        query = query.filter_by(status=status)
    
    query = query.order_by(AccessRequest.requested_at.desc())
    pagination = query.paginate(page=page, per_page=per_page)
    
    return jsonify({
        'requests': [r.to_dict(include_relations=True) for r in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@access_requests_bp.route('/', methods=['POST'])
@jwt_required()
@role_required('doctor', 'nurse')
def create_access_request():
    user_id = get_jwt_identity()
    data = request.get_json()
    
    access_request = AccessRequest(
        requester_id=user_id,
        patient_id=data['patient_id'],
        reason=data['reason']
    )
    
    db.session.add(access_request)
    db.session.commit()
    
    log_action('CREATE_ACCESS_REQUEST', 'access_request', access_request.id, patient_id=data['patient_id'])
    
    return jsonify(access_request.to_dict()), 201

@access_requests_bp.route('/<int:request_id>/approve', methods=['PUT'])
@jwt_required()
@role_required('admin')
def approve_request(request_id):
    user_id = get_jwt_identity()
    access_request = AccessRequest.query.get_or_404(request_id)
    
    access_request.status = 'approved'
    access_request.approved_by = user_id
    access_request.reviewed_at = datetime.utcnow()
    
    db.session.commit()
    log_action('APPROVE_ACCESS_REQUEST', 'access_request', request_id, patient_id=access_request.patient_id)
    
    return jsonify(access_request.to_dict())

@access_requests_bp.route('/<int:request_id>/deny', methods=['PUT'])
@jwt_required()
@role_required('admin')
def deny_request(request_id):
    user_id = get_jwt_identity()
    access_request = AccessRequest.query.get_or_404(request_id)
    
    access_request.status = 'denied'
    access_request.approved_by = user_id
    access_request.reviewed_at = datetime.utcnow()
    
    db.session.commit()
    log_action('DENY_ACCESS_REQUEST', 'access_request', request_id, patient_id=access_request.patient_id)
    
    return jsonify(access_request.to_dict())
