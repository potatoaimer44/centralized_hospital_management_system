from flask import Blueprint

api = Blueprint('api', __name__)

from .auth import auth_bp
from .users import users_bp
from .hospitals import hospitals_bp
from .patients import patients_bp
from .records import records_bp
from .vitals import vitals_bp
from .audit import audit_bp
from .access_requests import access_requests_bp
from .ai import ai_bp
from .dashboard import dashboard_bp
