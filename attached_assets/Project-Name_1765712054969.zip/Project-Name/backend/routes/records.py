from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.models.patient import Patient
from backend.models.medical_record import MedicalRecord
from backend.utils.decorators import role_required
from backend.utils.audit import log_action
from datetime import datetime

records_bp = Blueprint('records', __name__)

@records_bp.route('/', methods=['GET'])
@jwt_required()
def get_records():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    patient_id = request.args.get('patient_id', type=int)
    
    query = MedicalRecord.query
    
    if user.role == 'patient':
        patient = Patient.query.filter_by(user_id=user_id).first()
        if patient:
            query = query.filter_by(patient_id=patient.id)
        else:
            return jsonify({'records': [], 'total': 0})
    elif user.role == 'doctor':
        query = query.filter_by(doctor_id=user_id)
    
    if patient_id:
        query = query.filter_by(patient_id=patient_id)
    
    query = query.order_by(MedicalRecord.visit_date.desc())
    pagination = query.paginate(page=page, per_page=per_page)
    
    return jsonify({
        'records': [r.to_dict(include_relations=True) for r in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@records_bp.route('/<int:record_id>', methods=['GET'])
@jwt_required()
def get_record(record_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    record = MedicalRecord.query.get_or_404(record_id)
    
    if user.role == 'patient':
        patient = Patient.query.filter_by(user_id=user_id).first()
        if not patient or record.patient_id != patient.id:
            return jsonify({'error': 'Access denied'}), 403
    
    log_action('VIEW_RECORD', 'medical_record', record_id, patient_id=record.patient_id)
    
    return jsonify(record.to_dict(include_relations=True))

@records_bp.route('/', methods=['POST'])
@jwt_required()
@role_required('doctor')
def create_record():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    data = request.get_json()
    
    patient = Patient.query.get(data['patient_id'])
    if not patient:
        return jsonify({'error': 'Patient not found'}), 404
    
    record = MedicalRecord(
        patient_id=data['patient_id'],
        doctor_id=user_id,
        hospital_id=user.hospital_id,
        visit_date=datetime.strptime(data.get('visit_date', datetime.now().isoformat()), '%Y-%m-%dT%H:%M:%S') if data.get('visit_date') else datetime.now(),
        chief_complaint=data.get('chief_complaint'),
        diagnosis=data.get('diagnosis'),
        prescription=data.get('prescription'),
        lab_results=data.get('lab_results'),
        treatment_plan=data.get('treatment_plan'),
        notes=data.get('notes')
    )
    
    db.session.add(record)
    db.session.commit()
    
    log_action('CREATE_RECORD', 'medical_record', record.id, patient_id=record.patient_id)
    
    return jsonify(record.to_dict(include_relations=True)), 201

@records_bp.route('/<int:record_id>', methods=['PUT'])
@jwt_required()
@role_required('doctor')
def update_record(record_id):
    user_id = get_jwt_identity()
    record = MedicalRecord.query.get_or_404(record_id)
    
    if record.doctor_id != user_id:
        return jsonify({'error': 'Only the creating doctor can modify this record'}), 403
    
    data = request.get_json()
    
    if data.get('chief_complaint'):
        record.chief_complaint = data['chief_complaint']
    if data.get('diagnosis'):
        record.diagnosis = data['diagnosis']
    if data.get('prescription'):
        record.prescription = data['prescription']
    if data.get('lab_results'):
        record.lab_results = data['lab_results']
    if data.get('treatment_plan'):
        record.treatment_plan = data['treatment_plan']
    if data.get('notes'):
        record.notes = data['notes']
    
    db.session.commit()
    log_action('UPDATE_RECORD', 'medical_record', record_id, patient_id=record.patient_id)
    
    return jsonify(record.to_dict(include_relations=True))

@records_bp.route('/<int:record_id>', methods=['DELETE'])
@jwt_required()
@role_required('admin')
def delete_record(record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    patient_id = record.patient_id
    
    db.session.delete(record)
    db.session.commit()
    
    log_action('DELETE_RECORD', 'medical_record', record_id, patient_id=patient_id)
    
    return jsonify({'message': 'Record deleted successfully'})
