from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from backend.models import db
from backend.models.user import User
from backend.models.patient import Patient
from backend.models.audit_log import AuditLog
from backend.models.security_alert import SecurityAlert
from backend.models.record_match import RecordMatch
from backend.utils.decorators import role_required
from backend.utils.audit import log_action
from backend.services.audit_analyzer import AuditLogAnalyzer
from backend.services.record_matcher import RecordMatcher
import pandas as pd
from datetime import datetime, timedelta

ai_bp = Blueprint('ai', __name__)

audit_analyzer = AuditLogAnalyzer()
record_matcher = RecordMatcher(threshold=75)

@ai_bp.route('/analyze-logs', methods=['POST'])
@jwt_required()
@role_required('admin')
def analyze_logs():
    days = request.args.get('days', 7, type=int)
    
    since_date = datetime.utcnow() - timedelta(days=days)
    
    logs = AuditLog.query.filter(AuditLog.timestamp >= since_date).all()
    
    if not logs:
        return jsonify({'message': 'No logs found for analysis', 'alerts': []})
    
    logs_data = []
    for log in logs:
        logs_data.append({
            'id': log.id,
            'user_id': log.user_id,
            'action': log.action,
            'patient_id': log.patient_id,
            'timestamp': log.timestamp,
            'ip_address': log.ip_address
        })
    
    logs_df = pd.DataFrame(logs_data)
    
    alerts = audit_analyzer.detect_anomalies(logs_df)
    
    created_alerts = []
    for alert in alerts:
        security_alert = SecurityAlert(
            alert_type=alert['alert_type'],
            severity=alert['severity'],
            user_id=alert['user_id'],
            description=alert['description'],
            anomaly_score=alert['anomaly_score']
        )
        db.session.add(security_alert)
        created_alerts.append(alert)
    
    db.session.commit()
    
    log_action('ANALYZE_AUDIT_LOGS', 'ai_analysis', details={'alerts_generated': len(created_alerts)})
    
    return jsonify({
        'message': f'Analysis complete. {len(created_alerts)} anomalies detected.',
        'alerts': created_alerts
    })

@ai_bp.route('/security-alerts', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_security_alerts():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    is_resolved = request.args.get('is_resolved')
    severity = request.args.get('severity')
    
    query = SecurityAlert.query
    
    if is_resolved is not None:
        query = query.filter_by(is_resolved=is_resolved.lower() == 'true')
    
    if severity:
        query = query.filter_by(severity=severity)
    
    query = query.order_by(SecurityAlert.created_at.desc())
    pagination = query.paginate(page=page, per_page=per_page)
    
    alerts = []
    for alert in pagination.items:
        alert_dict = alert.to_dict()
        if alert.user:
            alert_dict['user_name'] = alert.user.full_name
        alerts.append(alert_dict)
    
    return jsonify({
        'alerts': alerts,
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@ai_bp.route('/security-alerts/<int:alert_id>/resolve', methods=['PUT'])
@jwt_required()
@role_required('admin')
def resolve_alert(alert_id):
    user_id = get_jwt_identity()
    alert = SecurityAlert.query.get_or_404(alert_id)
    
    alert.is_resolved = True
    alert.resolved_by = user_id
    alert.resolved_at = datetime.utcnow()
    
    db.session.commit()
    log_action('RESOLVE_SECURITY_ALERT', 'security_alert', alert_id)
    
    return jsonify(alert.to_dict())

@ai_bp.route('/match-records', methods=['POST'])
@jwt_required()
@role_required('admin')
def match_records():
    patients = Patient.query.join(User).all()
    
    if len(patients) < 2:
        return jsonify({'message': 'Not enough patients for matching', 'matches': []})
    
    patients_data = []
    for patient in patients:
        patients_data.append({
            'id': patient.id,
            'full_name': patient.user.full_name if patient.user else '',
            'date_of_birth': patient.date_of_birth,
            'phone': patient.user.phone if patient.user else '',
            'address': patient.address,
            'guardian_name': patient.guardian_name,
            'guardian_phone': patient.guardian_phone
        })
    
    matches = record_matcher.find_potential_matches(patients_data)
    
    created_matches = []
    for match in matches:
        existing = RecordMatch.query.filter(
            ((RecordMatch.patient_id_1 == match['patient_id_1']) & (RecordMatch.patient_id_2 == match['patient_id_2'])) |
            ((RecordMatch.patient_id_1 == match['patient_id_2']) & (RecordMatch.patient_id_2 == match['patient_id_1']))
        ).first()
        
        if not existing:
            record_match = RecordMatch(
                patient_id_1=match['patient_id_1'],
                patient_id_2=match['patient_id_2'],
                match_score=match['match_score']
            )
            db.session.add(record_match)
            created_matches.append(match)
    
    db.session.commit()
    
    log_action('MATCH_RECORDS', 'ai_analysis', details={'matches_found': len(created_matches)})
    
    return jsonify({
        'message': f'Found {len(matches)} potential duplicate records. {len(created_matches)} new matches created.',
        'matches': matches
    })

@ai_bp.route('/record-matches', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_record_matches():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    
    query = RecordMatch.query
    
    if status:
        query = query.filter_by(status=status)
    
    query = query.order_by(RecordMatch.match_score.desc())
    pagination = query.paginate(page=page, per_page=per_page)
    
    return jsonify({
        'matches': [m.to_dict(include_patients=True) for m in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    })

@ai_bp.route('/confirm-match/<int:match_id>', methods=['PUT'])
@jwt_required()
@role_required('admin')
def confirm_match(match_id):
    user_id = get_jwt_identity()
    data = request.get_json()
    
    match = RecordMatch.query.get_or_404(match_id)
    
    status = data.get('status', 'confirmed')
    if status not in ['confirmed', 'rejected']:
        return jsonify({'error': 'Invalid status'}), 400
    
    match.status = status
    match.reviewed_by = user_id
    match.reviewed_at = datetime.utcnow()
    
    db.session.commit()
    log_action('REVIEW_RECORD_MATCH', 'record_match', match_id)
    
    return jsonify(match.to_dict())
