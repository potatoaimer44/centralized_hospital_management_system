from flask import request
from flask_jwt_extended import get_jwt_identity
from backend.models import db
from backend.models.audit_log import AuditLog

def log_action(action, resource_type=None, resource_id=None, patient_id=None, details=None):
    try:
        user_id = get_jwt_identity()
        audit_log = AuditLog(
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            patient_id=patient_id,
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent', '')[:500],
            details=details
        )
        db.session.add(audit_log)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Error logging audit action: {e}")
