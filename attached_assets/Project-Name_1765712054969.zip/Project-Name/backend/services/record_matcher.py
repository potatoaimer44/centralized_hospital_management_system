from fuzzywuzzy import fuzz
from datetime import datetime

class RecordMatcher:
    def __init__(self, threshold=80):
        self.threshold = threshold
    
    def calculate_match_score(self, patient1, patient2):
        scores = []
        weights = []
        
        name1 = patient1.get('full_name', '') or ''
        name2 = patient2.get('full_name', '') or ''
        
        if name1 and name2:
            name_score = fuzz.token_sort_ratio(name1.lower(), name2.lower())
            scores.append(name_score)
            weights.append(0.4)
        
        dob1 = patient1.get('date_of_birth')
        dob2 = patient2.get('date_of_birth')
        
        if dob1 and dob2:
            if isinstance(dob1, str):
                dob1 = datetime.strptime(dob1, '%Y-%m-%d').date()
            if isinstance(dob2, str):
                dob2 = datetime.strptime(dob2, '%Y-%m-%d').date()
            
            if dob1 == dob2:
                dob_score = 100
            else:
                date_diff = abs((dob1 - dob2).days)
                dob_score = max(0, 100 - (date_diff * 10))
            scores.append(dob_score)
            weights.append(0.3)
        
        phone1 = patient1.get('phone', '') or ''
        phone2 = patient2.get('phone', '') or ''
        
        if phone1 and phone2:
            phone1_clean = ''.join(filter(str.isdigit, phone1))
            phone2_clean = ''.join(filter(str.isdigit, phone2))
            phone_score = fuzz.ratio(phone1_clean, phone2_clean)
            scores.append(phone_score)
            weights.append(0.15)
        
        address1 = patient1.get('address', '') or ''
        address2 = patient2.get('address', '') or ''
        
        if address1 and address2:
            address_score = fuzz.token_set_ratio(address1.lower(), address2.lower())
            scores.append(address_score)
            weights.append(0.15)
        
        if not scores:
            return 0.0
        
        total_weight = sum(weights)
        weighted_score = sum(s * w for s, w in zip(scores, weights)) / total_weight
        
        return round(weighted_score, 2)
    
    def find_potential_matches(self, patients):
        matches = []
        processed = set()
        
        for i, patient1 in enumerate(patients):
            for j, patient2 in enumerate(patients):
                if i >= j:
                    continue
                
                pair_key = (min(patient1['id'], patient2['id']), max(patient1['id'], patient2['id']))
                if pair_key in processed:
                    continue
                
                score = self.calculate_match_score(patient1, patient2)
                
                if score >= self.threshold:
                    matches.append({
                        'patient_id_1': patient1['id'],
                        'patient_id_2': patient2['id'],
                        'match_score': score / 100,
                        'patient1_name': patient1.get('full_name', ''),
                        'patient2_name': patient2.get('full_name', '')
                    })
                    processed.add(pair_key)
        
        matches.sort(key=lambda x: x['match_score'], reverse=True)
        
        return matches
