import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from datetime import datetime, timedelta

class AuditLogAnalyzer:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.is_trained = False
        
    def prepare_features(self, logs_df):
        if logs_df.empty:
            return pd.DataFrame()
            
        features = pd.DataFrame()
        
        if 'timestamp' in logs_df.columns:
            logs_df['timestamp'] = pd.to_datetime(logs_df['timestamp'])
            features['hour'] = logs_df['timestamp'].dt.hour
            features['day_of_week'] = logs_df['timestamp'].dt.dayofweek
            features['is_weekend'] = (logs_df['timestamp'].dt.dayofweek >= 5).astype(int)
        
        if 'user_id' in logs_df.columns and 'patient_id' in logs_df.columns:
            features['records_accessed'] = logs_df.groupby('user_id')['patient_id'].transform('count')
            features['unique_patients'] = logs_df.groupby('user_id')['patient_id'].transform('nunique')
        
        if 'action' in logs_df.columns:
            action_dummies = pd.get_dummies(logs_df['action'], prefix='action')
            features = pd.concat([features.reset_index(drop=True), action_dummies.reset_index(drop=True)], axis=1)
        
        features = features.fillna(0)
        
        return features
    
    def train_model(self, logs_df, contamination=0.05):
        if logs_df.empty or len(logs_df) < 10:
            return False
            
        features = self.prepare_features(logs_df)
        
        if features.empty or len(features) < 10:
            return False
        
        features_scaled = self.scaler.fit_transform(features)
        
        self.model = IsolationForest(
            contamination=contamination,
            random_state=42,
            n_estimators=100
        )
        self.model.fit(features_scaled)
        self.is_trained = True
        
        return True
        
    def detect_anomalies(self, logs_df):
        if not self.is_trained or self.model is None:
            if not self.train_model(logs_df):
                return []
        
        if logs_df.empty:
            return []
        
        features = self.prepare_features(logs_df)
        
        if features.empty:
            return []
        
        try:
            features_scaled = self.scaler.transform(features)
            predictions = self.model.predict(features_scaled)
            anomaly_scores = self.model.decision_function(features_scaled)
        except Exception as e:
            print(f"Error in anomaly detection: {e}")
            return []
        
        alerts = []
        for idx, (pred, score) in enumerate(zip(predictions, anomaly_scores)):
            if pred == -1:
                log_row = logs_df.iloc[idx]
                alert = {
                    'user_id': int(log_row.get('user_id', 0)) if pd.notna(log_row.get('user_id')) else None,
                    'timestamp': log_row['timestamp'].isoformat() if pd.notna(log_row.get('timestamp')) else None,
                    'anomaly_score': abs(float(score)),
                    'severity': self._calculate_severity(score),
                    'description': self._generate_description(log_row),
                    'alert_type': 'unusual_access_pattern'
                }
                alerts.append(alert)
        
        return alerts
    
    def _calculate_severity(self, score):
        abs_score = abs(score)
        if abs_score > 0.5:
            return 'critical'
        elif abs_score > 0.3:
            return 'high'
        elif abs_score > 0.1:
            return 'medium'
        else:
            return 'low'
    
    def _generate_description(self, log_row):
        user_id = log_row.get('user_id', 'unknown')
        action = log_row.get('action', 'unknown action')
        patient_id = log_row.get('patient_id', 'unknown')
        
        return f"Unusual access pattern detected: User {user_id} performed {action} on patient {patient_id}"
