from datetime import datetime
from . import db

class AccessRequest(db.Model):
    __tablename__ = 'access_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    requester_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'))
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')
    approved_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime)
    
    requester = db.relationship('User', foreign_keys=[requester_id], backref='access_requests_made')
    approver = db.relationship('User', foreign_keys=[approved_by], backref='access_requests_approved')
    
    def to_dict(self, include_relations=False):
        data = {
            'id': self.id,
            'requester_id': self.requester_id,
            'patient_id': self.patient_id,
            'reason': self.reason,
            'status': self.status,
            'approved_by': self.approved_by,
            'requested_at': self.requested_at.isoformat() if self.requested_at else None,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None
        }
        if include_relations:
            if self.requester:
                data['requester'] = self.requester.to_dict()
            if self.patient:
                data['patient'] = self.patient.to_dict(include_user=True)
        return data
