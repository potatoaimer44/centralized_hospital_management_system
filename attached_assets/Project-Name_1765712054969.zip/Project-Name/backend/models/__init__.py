from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

from .user import User
from .hospital import Hospital
from .patient import Patient
from .medical_record import MedicalRecord
from .vital_signs import VitalSigns
from .audit_log import AuditLog
from .access_request import AccessRequest
from .security_alert import SecurityAlert
from .record_match import RecordMatch
