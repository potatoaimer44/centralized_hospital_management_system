from datetime import datetime
from . import db

class MedicalRecord(db.Model):
    __tablename__ = 'medical_records'
    
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id', ondelete='CASCADE'))
    doctor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    hospital_id = db.Column(db.Integer, db.ForeignKey('hospitals.id'))
    visit_date = db.Column(db.DateTime, nullable=False)
    chief_complaint = db.Column(db.Text)
    diagnosis = db.Column(db.Text)
    prescription = db.Column(db.Text)
    lab_results = db.Column(db.Text)
    treatment_plan = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    doctor = db.relationship('User', backref='medical_records', foreign_keys=[doctor_id])
    vital_signs = db.relationship('VitalSigns', backref='medical_record', lazy='dynamic')
    
    def to_dict(self, include_relations=False):
        data = {
            'id': self.id,
            'patient_id': self.patient_id,
            'doctor_id': self.doctor_id,
            'hospital_id': self.hospital_id,
            'visit_date': self.visit_date.isoformat() if self.visit_date else None,
            'chief_complaint': self.chief_complaint,
            'diagnosis': self.diagnosis,
            'prescription': self.prescription,
            'lab_results': self.lab_results,
            'treatment_plan': self.treatment_plan,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        if include_relations:
            if self.doctor:
                data['doctor'] = self.doctor.to_dict()
            if self.hospital:
                data['hospital'] = self.hospital.to_dict()
            if self.patient:
                data['patient'] = self.patient.to_dict(include_user=True)
        return data
