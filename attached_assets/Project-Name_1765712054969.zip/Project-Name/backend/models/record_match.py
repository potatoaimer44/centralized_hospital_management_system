from datetime import datetime
from . import db

class RecordMatch(db.Model):
    __tablename__ = 'record_matches'
    
    id = db.Column(db.Integer, primary_key=True)
    patient_id_1 = db.Column(db.Integer, db.ForeignKey('patients.id'))
    patient_id_2 = db.Column(db.Integer, db.ForeignKey('patients.id'))
    match_score = db.Column(db.Numeric(5, 4))
    status = db.Column(db.String(20), default='pending')
    reviewed_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime)
    
    patient1 = db.relationship('Patient', foreign_keys=[patient_id_1], backref='matches_as_first')
    patient2 = db.relationship('Patient', foreign_keys=[patient_id_2], backref='matches_as_second')
    reviewer = db.relationship('User', foreign_keys=[reviewed_by], backref='reviewed_matches')
    
    def to_dict(self, include_patients=False):
        data = {
            'id': self.id,
            'patient_id_1': self.patient_id_1,
            'patient_id_2': self.patient_id_2,
            'match_score': float(self.match_score) if self.match_score else None,
            'status': self.status,
            'reviewed_by': self.reviewed_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None
        }
        if include_patients:
            if self.patient1:
                data['patient1'] = self.patient1.to_dict(include_user=True)
            if self.patient2:
                data['patient2'] = self.patient2.to_dict(include_user=True)
        return data
