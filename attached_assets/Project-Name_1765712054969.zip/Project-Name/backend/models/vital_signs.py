from datetime import datetime
from . import db

class VitalSigns(db.Model):
    __tablename__ = 'vital_signs'
    
    id = db.Column(db.Integer, primary_key=True)
    medical_record_id = db.Column(db.Integer, db.ForeignKey('medical_records.id', ondelete='CASCADE'))
    recorded_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    temperature = db.Column(db.Numeric(4, 2))
    blood_pressure = db.Column(db.String(10))
    pulse_rate = db.Column(db.Integer)
    respiratory_rate = db.Column(db.Integer)
    weight = db.Column(db.Numeric(5, 2))
    height = db.Column(db.Numeric(5, 2))
    bmi = db.Column(db.Numeric(4, 2))
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    recorder = db.relationship('User', backref='recorded_vitals', foreign_keys=[recorded_by])
    
    def to_dict(self):
        return {
            'id': self.id,
            'medical_record_id': self.medical_record_id,
            'recorded_by': self.recorded_by,
            'temperature': float(self.temperature) if self.temperature else None,
            'blood_pressure': self.blood_pressure,
            'pulse_rate': self.pulse_rate,
            'respiratory_rate': self.respiratory_rate,
            'weight': float(self.weight) if self.weight else None,
            'height': float(self.height) if self.height else None,
            'bmi': float(self.bmi) if self.bmi else None,
            'recorded_at': self.recorded_at.isoformat() if self.recorded_at else None
        }
